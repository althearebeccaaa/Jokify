package com.example.jokify;
import static android.content.Intent.getIntent;
import static androidx.core.content.ContextCompat.startActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.jokify.MainActivity;
import com.example.jokify.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FavoritesActivity extends AppCompatActivity {

    private ListView favoritesListView;
    private ArrayList<String> favoritesList;
    private Map<String, List<String>> jokesMap; // Add this line

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Enable the back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Initialize the favorites list and jokesMap
        favoritesList = getIntent().getStringArrayListExtra("favoritesList");
        jokesMap = (Map<String, List<String>>) getIntent().getSerializableExtra("jokesMap"); // Receive jokesMap

        // Set up the ListView adapter
        favoritesListView = findViewById(R.id.jokeListView);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                R.layout.item_joke,
                R.id.jokeQuestion,
                favoritesList
        ) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);

                // Get the joke text
                String joke = getItem(position);
                String[] jokeParts = joke.split("\\? ");

                // Set the joke title and question
                TextView jokeTitle = view.findViewById(R.id.jokeTitle);
                TextView jokeQuestion = view.findViewById(R.id.jokeQuestion);

                if (jokeParts.length >= 1) {
                    jokeTitle.setText(jokeParts[0]); // Set the joke title
                }
                if (jokeParts.length >= 2) {
                    jokeQuestion.setText(jokeParts[1] + "?"); // Set the joke question
                }

                return view;
            }
        };

        favoritesListView.setAdapter(adapter);

        // Handle item clicks
        favoritesListView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedJoke = favoritesList.get(position);
            openJokeDetail(selectedJoke);
        });
    }

    private void openJokeDetail(String joke) {
        // Open the Joke Detail Screen with the selected joke
        Intent intent = new Intent(this, JokeDetailActivity.class);
        intent.putExtra("selectedJoke", joke); // Pass the selected joke
        intent.putExtra("selectedCategory", getCategoryForJoke(joke)); // Pass the category
        intent.putStringArrayListExtra("favoritesList", favoritesList); // Pass the favorites list
        startActivity(intent);
    }

    // Helper method to find the category for a given joke
    private String getCategoryForJoke(String joke) {
        if (jokesMap == null || joke == null) {
            return ""; // Return an empty string if jokesMap or joke is null
        }

        for (Map.Entry<String, List<String>> entry : jokesMap.entrySet()) {
            if (entry.getValue().contains(joke)) {
                return entry.getKey(); // Return the category name
            }
        }
        return ""; // Return an empty string if the category is not found
    }

    @Override
    public boolean onSupportNavigateUp() {
        // Handle the back button in the Toolbar
        onBackPressed();
        return true;
    }
}