package com.example.jokify;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

public class CategoryAdapter extends BaseAdapter {
    private Context context;
    private List<Category> categories;

    public CategoryAdapter(Context context, List<Category> categories) {
        this.context = context;
        this.categories = categories;
    }

    @Override
    public int getCount() {
        return categories.size();
    }

    @Override
    public Object getItem(int position) {
        return categories.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_category, parent, false);
        }

        ImageView categoryImage = convertView.findViewById(R.id.categoryImage);
        TextView categoryName = convertView.findViewById(R.id.categoryName);
        FrameLayout categoryContainer = convertView.findViewById(R.id.categoryContainer); // Add this ID to your XML

        Category category = categories.get(position);

        // Set category image and name
        categoryImage.setImageResource(category.getImageResId());
        categoryName.setText(category.getName());

        // Set background drawable for the category container
        categoryContainer.setBackgroundResource(category.getBackgroundResId());

        return convertView;
    }
}