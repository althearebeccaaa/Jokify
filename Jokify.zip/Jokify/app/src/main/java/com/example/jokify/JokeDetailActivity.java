package com.example.jokify;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class JokeDetailActivity extends AppCompatActivity {

    private TextView jokeTitleDetail, jokeCategory, jokeText, jokePunchline;
    private ImageButton heartIcon;
    private ArrayList<String> favoritesList;
    private boolean isHeartFilled = false;
    private String selectedJoke;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_joke_detail);

        // Initialize views
        jokeTitleDetail = findViewById(R.id.jokeTitleDetail);
        jokeCategory = findViewById(R.id.jokeCategory);
        jokeText = findViewById(R.id.jokeText);
        jokePunchline = findViewById(R.id.jokePunchline);
        heartIcon = findViewById(R.id.heartIcon);
        LinearLayout textContainer = findViewById(R.id.textContainer);

        // Get data from the intent
        Intent intent = getIntent();
        selectedJoke = intent.getStringExtra("selectedJoke");
        String selectedCategory = intent.getStringExtra("selectedCategory");
        favoritesList = intent.getStringArrayListExtra("favoritesList");

        // Check if selectedJoke or selectedCategory is null
        if (selectedJoke == null || selectedCategory == null) {
            Toast.makeText(this, "Joke Selected", Toast.LENGTH_SHORT).show();
            finish(); // Close the activity if data is missing
            return;
        }

        // Check if favoritesList is null and initialize it if necessary
        if (favoritesList == null) {
            favoritesList = new ArrayList<>();
        }

        // Split the joke into title, question, and punchline
        String[] parts = selectedJoke.split("\\? ");
        if (parts.length < 3) {
            Toast.makeText(this, "Error: Invalid joke format.", Toast.LENGTH_SHORT).show();
            finish(); // Close the activity if the joke format is invalid
            return;
        }

        // Set the joke details
        jokeTitleDetail.setText(parts[0]);
        jokeText.setText(parts[1] + "?");
        jokePunchline.setText("Answer: " + parts[2]);
        jokeCategory.setText("Category: " + selectedCategory);

        // Set the heart icon state
        isHeartFilled = favoritesList.contains(selectedJoke);
        heartIcon.setImageResource(isHeartFilled ? R.drawable.heart_filled : R.drawable.heart);

        // Handle heart icon click
        heartIcon.setOnClickListener(v -> {
            if (isHeartFilled) {
                // Remove from favorites
                favoritesList.remove(selectedJoke);
                heartIcon.setImageResource(R.drawable.heart);
                Toast.makeText(this, "Removed from Favorites", Toast.LENGTH_SHORT).show();
            } else {
                // Add to favorites
                favoritesList.add(selectedJoke);
                heartIcon.setImageResource(R.drawable.heart_filled);
                Toast.makeText(this, "Added to Favorites", Toast.LENGTH_SHORT).show();
            }
            isHeartFilled = !isHeartFilled; // Toggle the state
        });

        // Handle back button click
        findViewById(R.id.backButton).setOnClickListener(v -> onBackPressed());
    }
}