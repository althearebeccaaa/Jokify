package com.example.jokify;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;
import android.widget.ViewSwitcher;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    private ViewFlipper viewFlipper;
    private GridView categoryGridView;
    private ListView jokeListView;
    private TextView categoryTitle, jokeTitle, jokeCategory, jokeText, jokePunchline;
    private TextView jokeTitleDetail; // Add this line

    // Joke data structure: Map<Category, List<Jokes>>
    private final HashMap<String, List<String>> jokesMap = new HashMap<>();
    private List<Category> categories;

    // Selected category for background color
    private Category selectedCategory;
    private boolean isHeartFilled = false;
    private ArrayList<String> favoritesList = new ArrayList<>();
    private static final String PREFS_NAME = "JokifyPrefs";
    private static final String FAVORITES_KEY = "favoritesList";


    private void saveFavorites() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putStringSet(FAVORITES_KEY, new HashSet<>(favoritesList));
        editor.apply();
    }

    private void loadFavorites() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        Set<String> favoritesSet = preferences.getStringSet(FAVORITES_KEY, new HashSet<>());
        favoritesList.clear();
        favoritesList.addAll(favoritesSet);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views and other components
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        viewFlipper = findViewById(R.id.viewFlipper);
        categoryGridView = findViewById(R.id.categoryGridView);
        jokeListView = findViewById(R.id.jokeListView);
        categoryTitle = findViewById(R.id.categoryTitle);
        jokeTitle = findViewById(R.id.jokeTitle);
        jokeCategory = findViewById(R.id.jokeCategory);
        jokeText = findViewById(R.id.jokeText);
        jokePunchline = findViewById(R.id.jokePunchline);
        jokeTitleDetail = findViewById(R.id.jokeTitleDetail);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // Load favorites from SharedPreferences
        loadFavorites();

        // Initialize categories and jokes
        initializeCategories();
        initializeJokes();

        // Splash screen timeout
        new Handler().postDelayed(() -> {
            // Check if the activity was launched from FavoritesActivity
            Intent intent = getIntent();
            if (intent != null && intent.hasExtra("selectedJoke")) {
                String selectedJoke = intent.getStringExtra("selectedJoke");
                String selectedCategoryName = intent.getStringExtra("selectedCategory");

                // Find the selected category
                for (Category category : categories) {
                    if (category.getName().equals(selectedCategoryName)) {
                        selectedCategory = category; // Set the selected category
                        break;
                    }
                }

                if (selectedCategory != null) {
                    showJokeDetail(selectedJoke); // Navigate directly to the joke detail screen
                } else {
                    Toast.makeText(this, "Category not found for the selected joke.", Toast.LENGTH_SHORT).show();
                    viewFlipper.setDisplayedChild(1); // Fallback to the category grid
                }
            } else {
                viewFlipper.setDisplayedChild(1); // Show the category grid
            }
        }, 2000);

        if (getSupportActionBar() != null) {
            getSupportActionBar().show();
        }

        // Set up click listeners
        setupClickHandlers();
    }

    private void initializeCategories() {
        // Initialize categories with background drawable resources and colors
        categories = new ArrayList<>();
        categories.add(new Category("Animals", R.drawable.animals, R.drawable.bg_animals, "#FEDA49"));
        categories.add(new Category("School", R.drawable.school, R.drawable.bg_school, "#B3F48457"));
        categories.add(new Category("Countries", R.drawable.countries, R.drawable.bg_countries, "#B3EE8A10"));
        categories.add(new Category("Movies", R.drawable.movies, R.drawable.bg_movies, "#B3FCEAD4"));
        categories.add(new Category("Fruits", R.drawable.fruits, R.drawable.bg_fruits, "#B37B4808"));
        categories.add(new Category("Food", R.drawable.foods, R.drawable.bg_food, "#B39C746C"));
        categories.add(new Category("Dark Humor", R.drawable.darkhumor, R.drawable.bg_dark_humor, "#B3CCA4A4"));
        categories.add(new Category("Politics", R.drawable.politics, R.drawable.bg_politics, "#B3625551"));

        // Set up the GridView adapter
        CategoryAdapter adapter = new CategoryAdapter(this, categories);
        categoryGridView.setAdapter(adapter);

        // Adjust GridView spacing
        categoryGridView.setVerticalSpacing(16);
        categoryGridView.setHorizontalSpacing(16);
        categoryGridView.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
    }

    private void initializeJokes() {
        List<String> animalJokes = new ArrayList<>();
        animalJokes.add("Cow With No Legs? What do you call a cow with no legs? Ground Beef");
        animalJokes.add("Lion's Greetings? How does a lion greet other animals? With a big roar!");
        animalJokes.add("Cow's Favorite Movie? What's a cow's favorite movie? Moo-vies!");
        animalJokes.add("Chicken Crossing the Road? Why did the chicken cross the road? To get to the other side!");
        animalJokes.add("Elephant in the Room? Why don’t elephants use computers? They’re afraid of the mouse!");
        animalJokes.add("Penguin's Favorite Food? What do penguins eat for lunch? Iceberg-ers!");
        animalJokes.add("Frog's Favorite Drink? What do frogs drink? Croaka-Cola!");
        jokesMap.put("Animals", animalJokes);

        List<String> schoolJokes = new ArrayList<>();
        schoolJokes.add("Math Problem? Why was the math book sad? It had too many problems!");
        schoolJokes.add("Homework Excuse? Why did the student eat his homework? Because the teacher said it was a piece of cake!");
        schoolJokes.add("Classroom Mystery? Why don’t skeletons fight in the classroom? They don’t have the guts!");
        schoolJokes.add("Teacher's Pet? Why did the teacher wear sunglasses? Because her students were so bright!");
        schoolJokes.add("Lunchtime Fun? Why did the student bring a ladder to school? To reach the high grades!");
        schoolJokes.add("Science Class? Why don’t scientists trust atoms? Because they make up everything!");
        jokesMap.put("School", schoolJokes);

        // Countries Category (6 jokes)
        List<String> countriesJokes = new ArrayList<>();
        countriesJokes.add("French Bread? Why did the French chef go broke? He lost his dough!");
        countriesJokes.add("Italian Pasta? Why do Italians love pasta? Because it’s amore!");
        countriesJokes.add("Canadian Weather? Why don’t Canadians ever get lost? Because they always follow the snow!");
        countriesJokes.add("Australian Kangaroo? Why don’t kangaroos live in Australia? Oh wait, they do!");
        countriesJokes.add("British Tea? Why did the British tea go to therapy? It had too many steep issues!");
        countriesJokes.add("Mexican Taco? Why did the taco go to Mexico? To find its roots!");
        jokesMap.put("Countries", countriesJokes);

        // Movies Category (6 jokes)
        List<String> moviesJokes = new ArrayList<>();
        moviesJokes.add("Star Wars? Why did Darth Vader cross the road? To get to the dark side!");
        moviesJokes.add("Jurassic Park? Why don’t dinosaurs watch Jurassic Park? They find it too scary!");
        moviesJokes.add("Harry Potter? Why did Harry Potter go to the bank? To check his vault!");
        moviesJokes.add("Titanic? Why did the iceberg break up with the Titanic? It was a cold relationship!");
        moviesJokes.add("Superhero Movies? Why don’t superheroes ever get cold? Because they wear capes!");
        moviesJokes.add("Pirates of the Caribbean? Why did the pirate go to the movies? For the booty!");
        jokesMap.put("Movies", moviesJokes);

        // Fruits Category (6 jokes)
        List<String> fruitsJokes = new ArrayList<>();
        fruitsJokes.add("Banana Slip? Why did the banana go to the doctor? It wasn’t peeling well!");
        fruitsJokes.add("Apple’s Day Off? Why did the apple take a day off? It needed a little core time!");
        fruitsJokes.add("Orange Juice? Why did the orange stop in the middle of the road? It ran out of juice!");
        fruitsJokes.add("Grape Expectations? Why don’t grapes ever get lonely? Because they come in bunches!");
        fruitsJokes.add("Pineapple Party? Why did the pineapple go to the party? Because it was the life of the fruit bowl!");
        fruitsJokes.add("Watermelon’s Secret? Why did the watermelon break up with the cantaloupe? It needed some space!");
        jokesMap.put("Fruits", fruitsJokes);

        // Foods Category (6 jokes)
        List<String> foodsJokes = new ArrayList<>();
        foodsJokes.add("Pizza’s Problem? Why did the pizza go to therapy? It had too many toppings!");
        foodsJokes.add("Burger’s Dream? Why did the burger go to school? To get a little more well-rounded!");
        foodsJokes.add("Ice Cream’s Day? Why did the ice cream go to the gym? To get a little more scoop!");
        foodsJokes.add("Pasta’s Secret? Why did the pasta go to the party? It wanted to be saucy!");
        foodsJokes.add("Sushi’s Adventure? Why did the sushi go on vacation? To get a little roll!");
        foodsJokes.add("Pancake’s Problem? Why did the pancake go to the doctor? It was feeling flat!");
        jokesMap.put("Foods", foodsJokes);

        // Dark Humor Category (6 jokes)
        List<String> darkHumorJokes = new ArrayList<>();
        darkHumorJokes.add("Graveyard Shift? Why don’t skeletons fight each other? They don’t have the guts!");
        darkHumorJokes.add("Zombie’s Day Off? Why did the zombie take a day off? It needed to unwind!");
        darkHumorJokes.add("Vampire’s Diet? Why don’t vampires eat clowns? They taste funny!");
        darkHumorJokes.add("Ghost’s Job? Why did the ghost get fired? It couldn’t handle the spirit of the job!");
        darkHumorJokes.add("Witch’s Problem? Why did the witch go to the doctor? She was feeling a little hexed!");
        darkHumorJokes.add("Mummy’s Secret? Why don’t mummies take vacations? They’re afraid to unwind!");
        jokesMap.put("Dark Humor", darkHumorJokes);

        // Politics Category (6 jokes)
        List<String> politicsJokes = new ArrayList<>();
        politicsJokes.add("Election Day? Why did the politician bring a ladder to the election? To climb the polls!");
        politicsJokes.add("Campaign Trail? Why don’t politicians ever get lost? They always follow the money!");
        politicsJokes.add("Debate Night? Why did the politician go to the debate? To argue his point!");
        politicsJokes.add("Budget Cuts? Why did the politician cut the budget? To save face!");
        politicsJokes.add("Political Promise? Why don’t politicians keep their promises? They’re too busy campaigning!");
        politicsJokes.add("Voting Booth? Why did the voter bring a flashlight to the booth? To shed some light on the issues!");
        jokesMap.put("Politics", politicsJokes);
    }

    private void setupClickHandlers() {
        // Category selection
        categoryGridView.setOnItemClickListener((parent, view, position, id) -> {
            selectedCategory = (Category) parent.getItemAtPosition(position); // Initialize selectedCategory
            showJokesForCategory(selectedCategory.getName());
        });

        // Joke selection
        jokeListView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedJoke = (String) parent.getItemAtPosition(position);
            showJokeDetail(selectedJoke);
        });

        // Back buttons
        findViewById(R.id.backButton).setOnClickListener(v -> viewFlipper.setDisplayedChild(1)); // Back to category grid
        findViewById(R.id.backButton2).setOnClickListener(v -> {
            // Check if the user came from Favorites
            Intent intent = getIntent();
            if (intent != null && intent.hasExtra("fromFavorites")) {
                // Navigate back to FavoritesActivity
                Intent favoritesIntent = new Intent(this, FavoritesActivity.class);
                favoritesIntent.putStringArrayListExtra("favoritesList", favoritesList);
                startActivity(favoritesIntent);
            } else {
                // Navigate back to the joke list
                viewFlipper.setDisplayedChild(2);
            }
        });
    }

    private void showJokesForCategory(String categoryName) {
        if (selectedCategory == null) {
            Toast.makeText(this, "Selected category is null.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Log the selected category and its background color
        Log.d("MainActivity", "Selected Category: " + selectedCategory.getName());
        Log.d("MainActivity", "Background Color: " + selectedCategory.getBackgroundColor());

        // Set the background color for the joke list screen
        LinearLayout jokeListLayout = findViewById(R.id.jokeListLayout);
        if (jokeListLayout == null) {
            Toast.makeText(this, "jokeListLayout is null.", Toast.LENGTH_SHORT).show();
            return;
        }
        jokeListLayout.setBackgroundColor(android.graphics.Color.parseColor(selectedCategory.getBackgroundColor()));

        // Get jokes for the selected category
        List<String> jokes = jokesMap.get(categoryName);
        if (jokes == null || jokes.isEmpty()) {
            Toast.makeText(this, "No jokes found for this category.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Set up the ListView adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                R.layout.item_joke,
                R.id.jokeQuestion,
                jokes
        ) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);

                // Get the joke text
                String joke = getItem(position);
                String[] jokeParts = joke.split("\\? ");

                // Set the joke title and question
                TextView jokeTitle = view.findViewById(R.id.jokeTitle);
                TextView jokeQuestion = view.findViewById(R.id.jokeQuestion);

                if (jokeParts.length >= 1) {
                    jokeTitle.setText(jokeParts[0]); // Set the joke title
                }
                if (jokeParts.length >= 2) {
                    jokeQuestion.setText(jokeParts[1] + "?"); // Set the joke question
                }

                return view;
            }
        };

        // Set the adapter to the ListView
        jokeListView.setAdapter(adapter);

        // Switch to the joke list view
        viewFlipper.setDisplayedChild(2); // Index 2 corresponds to the joke list

        invalidateOptionsMenu();
    }


    private void showJokeDetail(String fullJoke) {
        if (selectedCategory == null) {
            Toast.makeText(this, "Selected category is null.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Open the Joke Detail Screen with the selected joke
        Intent intent = new Intent(this, JokeDetailActivity.class);
        intent.putExtra("selectedJoke", fullJoke); // Pass the selected joke
        intent.putStringArrayListExtra("favoritesList", favoritesList); // Pass the favorites list
        startActivity(intent);

        // Log the selected category and its background color
        Log.d("MainActivity", "Selected Category: " + selectedCategory.getName());
        Log.d("MainActivity", "Background Color: " + selectedCategory.getBackgroundColor());

        // Set the background color for the text container
        LinearLayout textContainer = findViewById(R.id.textContainer);
        if (textContainer == null) {
            Toast.makeText(this, "textContainer is null.", Toast.LENGTH_SHORT).show();
            return;
        }
        textContainer.setBackgroundColor(android.graphics.Color.parseColor(selectedCategory.getBackgroundColor()));

        ImageButton heartIcon = findViewById(R.id.heartIcon);
        if (heartIcon == null) {
            Toast.makeText(this, "heartIcon is null.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if the joke is in the favorites list
        // Inside the heartIcon.setOnClickListener in MainActivity.java
        heartIcon.setOnClickListener(v -> {
            if (isHeartFilled) {
                // Show confirmation dialog before removing from favorites
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Remove from Favorites")
                        .setMessage("Are you sure you want to remove this joke from favorites?")
                        .setPositiveButton("Yes", (dialog, which) -> {
                            // Remove from favorites
                            favoritesList.remove(fullJoke);
                            heartIcon.setImageResource(R.drawable.heart); // Change to unfilled heart
                            isHeartFilled = false;
                            saveFavorites(); // Save updated favorites list
                            Toast.makeText(MainActivity.this, "Removed from Favorites", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                        .show();
            } else {
                // Add to favorites (no confirmation needed)
                favoritesList.add(fullJoke);
                heartIcon.setImageResource(R.drawable.heart_filled); // Change to filled heart
                isHeartFilled = true;
                saveFavorites(); // Save updated favorites list
                Toast.makeText(MainActivity.this, "Added to Favorites", Toast.LENGTH_SHORT).show();
            }
        });

        // Split the joke into title, question, and punchline
        String[] parts = fullJoke.split("\\? ");
        if (parts.length < 3) return; // Ensure there are at least 3 parts

        // Set the joke title (outside the yellow background)
        jokeTitle.setText(parts[0]);

        // Set the joke title (inside the yellow background)
        jokeTitleDetail.setText(parts[0]);

        // Set the joke question (inside the yellow background)
        jokeText.setText(parts[1] + "?");

        // Set the punchline (inside the yellow background)
        jokePunchline.setText("Answer: " + parts[2]);

        // Set the category (inside the yellow background)
        jokeCategory.setText("Category: " + selectedCategory.getName());

        // Switch to the joke detail view
        viewFlipper.setDisplayedChild(3);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main menu (About item)
        getMenuInflater().inflate(R.menu.main_menu, menu);

        // Check if the current screen is the Joke List Screen
        if (viewFlipper.getDisplayedChild() == 2) { // Index 2 corresponds to the Joke List Screen
            // Inflate the Joke List menu (Search icon)
            getMenuInflater().inflate(R.menu.joke_list_menu, menu);
        }

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle App Bar item clicks
        int id = item.getItemId();

        if (id == R.id.action_favorites) {
            // Navigate to the Favorites Screen
            Intent intent = new Intent(this, FavoritesActivity.class);
            intent.putStringArrayListExtra("favoritesList", favoritesList); // Pass the favorites list
            intent.putExtra("jokesMap", jokesMap); // Pass the jokesMap as Serializable
            startActivity(intent);
            return true;
        } else if (id == R.id.action_about) {
            // Handle about action
            Toast.makeText(this, "About clicked", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == android.R.id.home) {
            // Handle back button click
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        // Check if the current screen is the category screen (index 1 in ViewFlipper)
        if (viewFlipper.getDisplayedChild() == 1) {
            // Show exit confirmation dialog
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Exit App")
                    .setMessage("Are you sure you want to exit the app?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        // Exit the app
                        finish();
                    })
                    .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                    .show();
        } else {
            // Navigate back to the previous screen
            super.onBackPressed();
        }
    }
}

