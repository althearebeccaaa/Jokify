package com.example.jokify;

public class Category {
    private String name;
    private int imageResId;
    private int backgroundResId; // For rounded corner backgrounds
    private String backgroundColor; // For joke list and detail screens

    public Category(String name, int imageResId, int backgroundResId, String backgroundColor) {
        this.name = name;
        this.imageResId = imageResId;
        this.backgroundResId = backgroundResId;
        this.backgroundColor = backgroundColor;
    }

    public String getName() {
        return name;
    }

    public int getImageResId() {
        return imageResId;
    }

    public int getBackgroundResId() {
        return backgroundResId;
    }

    public String getBackgroundColor() {
        return backgroundColor;
    }
}